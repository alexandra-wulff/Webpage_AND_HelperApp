var mainText = document.getElementById("mainText");
var submitBtn = document.getElementById("submitBtn");
var fireHeading = document.getElementById("fireHeading");
var circleTree = document.getElementById("circleTree");
var loadingCup = document.getElementById("loadingCup");
var fact = document.getElementById("fact");



var name1 = document.getElementById("name1");
var points1 = document.getElementById("points1");

var name2 = document.getElementById("name2");
var points2 = document.getElementById("points2");

var name3 = document.getElementById("name3");
var points3 = document.getElementById("points3");

var pointScoreMap = new Map(); //used to map top score users
var numberOfUsers; //or just get array length or map size

var ref = firebase.database().ref().child("test");
var query = ref.orderByKey();
query.on("value", function(snapshot) {
    numberOfUsers = snapshot.numChildren();
    console.log("Number of users " + numberOfUsers);
    updateCircleTree(numberOfUsers);
    updateLoadingCup(numberOfUsers);
    updateFactBubble(numberOfUsers);

    var totalPoints = 0;
    snapshot.forEach(function(childSnapshot) {
        var userName;
        var childData = childSnapshot.val();
        var usersPoints = 0;
        for (let [key, value] of Object.entries(childData)) {
            if (key === "name") {
                userName = value;
            }
            if (key === "points") {
                usersPoints = value;
                totalPoints = totalPoints + value;
                pointScoreMap.set(userName, usersPoints);
                setLeaderboardScore();
            }
        }
        console.log(userName + " has " + usersPoints + " points!");
    });
    console.log("Total pointscore for all users is: " + totalPoints);
});

function setLeaderboardScore() {
    const mapSort1 = new Map([...pointScoreMap.entries()].sort((a, b) => b[1] - a[1]));
    console.log(mapSort1);
    setValues(mapSort1);
}

function setValues(sortedMap){
    var count = 0;
    var get_keys = sortedMap.keys(); 
    for(var name of get_keys) {
        count = count + 1;
        if(count === 1) {
            setFirstPlace(name, sortedMap.get(name));
        }
        if(count === 2) {
            setSecondPlace(name, sortedMap.get(name));
        }
        if(count === 3) {
            setThirdPlace(name, sortedMap.get(name));
        }
    }   
}

function setFirstPlace(name, points) {
    name1.innerText = name;
    points1.innerText = points;
}

function setSecondPlace(name, points) {
    name2.innerText = name;
    points2.innerText = points;
}

function setThirdPlace(name, points) {
    name3.innerText = name;
    points3.innerText = points;
}

function updateLoadingCup(numberOfUsers) {
    if (numberOfUsers < 51) { 
        loadingCup.src = "./picture/cup/cup_0.png";
    } else if (numberOfUsers >= 51 && numberOfUsers < 70) { 
        loadingCup.src = "./picture/cup/cup_1.png";
    } else if (numberOfUsers >= 70 && numberOfUsers < 97) { 
        loadingCup.src = "./picture/cup/cup_2.png";
    } else if (numberOfUsers >= 97) { 
        loadingCup.src = "./picture/cup/cup_3.png";
    } 
}

function updateFactBubble(numberOfUsers) {
    if (numberOfUsers < 51) { 
        fact.src = "./picture/facts/fact1.png";
    } else if (numberOfUsers >= 51 && numberOfUsers < 70) { 
        fact.src = "./picture/facts/fact2.png";
    } else if (numberOfUsers >= 70 && numberOfUsers < 97) { 
        fact.src = "./picture/facts/fact3.png";
    } else if (numberOfUsers >= 97 && numberOfUsers < 130) { 
        fact.src = "./picture/facts/fact4.png";
    } else if (numberOfUsers >= 130) { 
        fact.src = "./picture/facts/fact5.png";
    }
}

function updateCircleTree(numberOfUsers) {
    if (numberOfUsers < 43) {
        circleTree.src = "./picture/tree/circleTree33.png";
    } else if (numberOfUsers >= 43 && numberOfUsers < 51) {
        circleTree.src = "./picture/tree/circleTree43.png";
    } else if (numberOfUsers >= 51 && numberOfUsers < 60) {
        circleTree.src = "./picture/tree/circleTree51.png";
    } else if (numberOfUsers >= 60 && numberOfUsers < 70) {
        circleTree.src = "./picture/tree/circleTree60.png";
    } else if (numberOfUsers >= 70 && numberOfUsers < 82) {
        circleTree.src = "./picture/tree/circleTree70.png";
    } else if (numberOfUsers >= 82 && numberOfUsers < 97) {
        circleTree.src = "./picture/tree/circleTree82.png";
    } else if (numberOfUsers >= 97 && numberOfUsers < 130) {
        circleTree.src = "./picture/tree/circleTree97.png";
    } else if (numberOfUsers >= 130) {
        circleTree.src = "./picture/tree/circleTree159.png";
    } else {}
}