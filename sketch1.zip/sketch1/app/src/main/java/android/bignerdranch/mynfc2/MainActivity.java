package android.bignerdranch.mynfc2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG_LOG = "GreenBean";
    private HashMap<String, Integer> tagIdPointsMap = new HashMap<>();
    private int totalPoints = 0;

    TextView levelView;
    TextView totalPointScoreView;
    TextView rankMonthView;
    TextView rankSemesterView;
    TextView rankAllTimeView;
    ImageView imageLevel;

    NfcAdapter nNfcAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nNfcAdapter = nNfcAdapter.getDefaultAdapter(this);
        totalPointScoreView = findViewById(R.id.pointScore);
        totalPointScoreView.setText("Your point score: " + totalPoints);

        levelView = findViewById(R.id.level);
        imageLevel = findViewById(R.id.imageLevel);
        rankMonthView = findViewById(R.id.profileRankMonth);
        rankSemesterView = findViewById(R.id.profileRankSemester);
        rankAllTimeView = findViewById(R.id.profileRankAllTime);

    }


    private void enableForegroundDispatchSystem() {

        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_RECEIVER_REPLACE_PENDING);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        IntentFilter[] intentFilters = new IntentFilter[]{};

        if (nNfcAdapter != null) {
            nNfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilters, null);
        }

    }


    private void disableForegroundDispatchSystem() {
        nNfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        enableForegroundDispatchSystem();
    }

    @Override
    protected void onPause() {
        super.onPause();
        disableForegroundDispatchSystem();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        if (intent.hasExtra(NfcAdapter.EXTRA_TAG)) {

            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            String tagId = tag.getId().toString(); //unique tagId given at first scan

            Parcelable[] parcelables = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            if (parcelables != null && parcelables.length > 0) {
                String currentMessage = readTextFromMessage((NdefMessage) parcelables[0]);


                validateTagId(tag, currentMessage, tagId);
                totalPointScoreView.setText("Your point score: " + totalPoints);
                setLevelPicture();
                Toast.makeText(this, "Your tag has been successfully scanned! We have added 1 point to your total score :)", Toast.LENGTH_SHORT).show();

            } else {
                NdefMessage newMessage = createNdefMessage(tagId + "");
                writeNdefMessage(tag, newMessage);
                Toast.makeText(this, "Your tag has been successfully registered!", Toast.LENGTH_SHORT).show();
                Toast.makeText(this, "Next time your tag is scanned, 1 point will be added to your total score :)", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void validateTagId(Tag tag, String currentMessage, String tagId) {

        if (tagIdPointsMap.containsKey(currentMessage)) {
            Log.e(TAG_LOG, "Recognized NFC tagId");

            int currentNumberOfPoints = tagIdPointsMap.get(currentMessage);
            tagIdPointsMap.put(currentMessage, currentNumberOfPoints + 1);
            totalPoints += 1;


        } else if (!tagIdPointsMap.containsKey(currentMessage)) {
            Log.e(TAG_LOG, "Does not recognize NFC tagId");

            NdefMessage ndefMessage = createNdefMessage(tagId + "");
            writeNdefMessage(tag, ndefMessage);
            tagIdPointsMap.put(tagId, 0);

        }

    }

    private int getTotalNumberOfPoints() {
        return totalPoints;
    }

    private int getTagPointScore(String tagId) {
        return tagIdPointsMap.get(tagId);
    }

    private void setLevelPicture() {

        int points = getTotalNumberOfPoints();
        if (points == 0) {
            imageLevel.setImageResource(R.drawable.planet);
            levelView.setText("Level 1: Seed");
            rankMonthView.setText("-");
            rankSemesterView.setText("-");
            rankAllTimeView.setText("-");

        } else if (points >= 1 && points < 5) {
            imageLevel.setImageResource(R.drawable.seeds);
            levelView.setText("Level 2: Seed");
            rankMonthView.setText("40th");
            rankSemesterView.setText("18th");
            rankAllTimeView.setText("35th");

        } else if (points >= 5 && points < 10) {
            imageLevel.setImageResource(R.drawable.plant_two_leaves);
            levelView.setText("Level 3: Sprout");
            rankMonthView.setText("30th");
            rankSemesterView.setText("14th");
            rankAllTimeView.setText("25th");

        } else if (points >= 10 && points < 15) {
            imageLevel.setImageResource(R.drawable.plant_four_leaves);
            levelView.setText("Level 4: Toddler Tree");
            rankMonthView.setText("20th");
            rankSemesterView.setText("9th");
            rankAllTimeView.setText("20th");

        } else if (points >= 15) {
            imageLevel.setImageResource(R.drawable.tree);
            levelView.setText("Level 5: Teen Tree");
            rankMonthView.setText("2nd");
            rankSemesterView.setText("2nd");
            rankAllTimeView.setText("5th");

        }
    }


    private void formatTag(Tag tag, NdefMessage ndefMessage) {
        try {

            NdefFormatable ndefFormatable = NdefFormatable.get(tag);
            if (ndefFormatable == null) {
                Log.e(TAG_LOG, "Tag is not Ndef formatable:(");
                return;
            }
            ndefFormatable.connect();
            ndefFormatable.format(ndefMessage);
            ndefFormatable.close();

        } catch (Exception e) {
            Log.e("formatTag", e.getMessage());
        }

    }

    private void writeNdefMessage(Tag tag, NdefMessage ndefMessage) {
        try {
            if (tag == null) {  // checks if tag is empty
                Toast.makeText(this, "Tag object cannot be null", Toast.LENGTH_LONG).show();
                return;
            }
            Ndef ndef = Ndef.get(tag);  // format tag with Ndef format and write NdefMessage

            if (ndef == null) {
                formatTag(tag, ndefMessage);
            } else {
                ndef.connect();

                if (!ndef.isWritable()) {

                    Log.e(TAG_LOG, "Tag is not writeable");
                    ndef.close();
                    return;
                }

                ndef.writeNdefMessage(ndefMessage);
                ndef.close();

                Log.e(TAG_LOG, "Tag is written");
                Log.e(TAG_LOG, "Tag write" + ndefMessage);
            }

        } catch (Exception e) {
            Log.e("writeNdefMessage", e.getMessage());
        }
    }


    private NdefRecord createTextRecord(String content) {
        try {
            byte[] language;
            language = Locale.getDefault().getLanguage().getBytes("UTF-8");

            final byte[] text = content.getBytes("UTF-8");
            final int languageSize = language.length;
            final int textLength = text.length;
            final ByteArrayOutputStream payload = new ByteArrayOutputStream(1 + languageSize + textLength);

            payload.write((byte) (languageSize & 0x1F));
            payload.write(language, 0, languageSize);
            payload.write(text, 0, textLength);

            return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new byte[0], payload.toByteArray());

        } catch (UnsupportedEncodingException e) {
            Log.e("createTextRecord", e.getMessage());

        }
        return null;

    }

    private NdefMessage createNdefMessage(String content) {
        NdefRecord ndefRecord = createTextRecord(content);
        NdefMessage ndefMessage = new NdefMessage(new NdefRecord[]{ndefRecord});

        return ndefMessage;
    }

    private String getTextFromNdefRecord(NdefRecord ndefRecord) {
        String tagContent = null;

        try {
            byte[] payload = ndefRecord.getPayload();
            String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16";
            int languageSize = payload[0] & 0063;
            tagContent = new String(payload, languageSize + 1,
                    payload.length - languageSize - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e("getTextFromNdefRecord", e.getMessage());
        }
        return tagContent;

    }

    private String readTextFromMessage(NdefMessage ndefMessage) {
        NdefRecord[] ndefRecords = ndefMessage.getRecords();

        if (ndefRecords != null && ndefRecords.length > 0) {
            NdefRecord ndefRecord = ndefRecords[0];
            String tagContent = getTextFromNdefRecord(ndefRecord);
            return tagContent;
        } else {
            Toast.makeText(this, "No Ndef records found", Toast.LENGTH_LONG).show();
            return null;
        }
    }


    //end of MainActivity class
}
