package com.example.autogenerateuser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private String TAG_LOG = "TAG_LOG";
    private FirebaseDatabase mDatabase;
    private DatabaseReference mReferenceUsers;

    private Button add_1_user_btn;
    private Button add_5_users_btn;
    private Button add_10_users_btn;

    private Button add_real_user_btn;
    private int numberOfRealUsers = 0; //remember to delete all users in database before starting

    private ArrayList<String> realUserNames = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatabase = FirebaseDatabase.getInstance();
        mReferenceUsers = mDatabase.getReference("test");

        add_1_user_btn = findViewById(R.id.add_1_user_btn);
        add_5_users_btn = findViewById(R.id.add_5_users_btn);
        add_10_users_btn = findViewById(R.id.add_10_users_btn);
        add_real_user_btn = findViewById(R.id.add_real_user_btn);

        makeUserNames(); //create array of 10 real user names


        add_1_user_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Create 1 new test user and push to database
                createTestUser(1);

            }
        });


        add_5_users_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Create 5 new test users and push to database
                createTestUser(5);

            }
        });

        add_10_users_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Create 10 new test users and push to database
                createTestUser(10);

            }
        });

        add_real_user_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Create 1 new real user with a real name and push to database
                //A real user has higher points than test users
                createRealUser();
            }
        });


    }

    private void pushToDataBase(User user) {
        mReferenceUsers.push().setValue(user);
        Log.e(TAG_LOG, "User: " + user.getName() + " added");

    }

    private void createRealUser() {
        if (numberOfRealUsers < realUserNames.size()) {
            String name = realUserNames.get(numberOfRealUsers);
            int points = getMedalPoint();
            User newRealUser = new User(name, points);
            numberOfRealUsers += 1;

            pushToDataBase(newRealUser);

        }
        if (numberOfRealUsers >= realUserNames.size()) {
            Toast.makeText(MainActivity.this, "Cannot add more real users, max reached", Toast.LENGTH_LONG).show();
        }

    }


    private void makeUserNames() {
        realUserNames.add("Elsa");
        realUserNames.add("Anna");
        realUserNames.add("Olaf");
        realUserNames.add("Tomas");
        realUserNames.add("Ulla");
        realUserNames.add("Nicole");
        realUserNames.add("Troels");
        realUserNames.add("Alexandra");
        realUserNames.add("Santa Claus");
        realUserNames.add("James Bond");
    }

    private void createTestUser(int numberOfUsers) {
        for (int i = 0; i < numberOfUsers; i++) {
            int points = getRandomPoint();
            String name = getRandomTestName();
            User newUser = new User(name, points);

            pushToDataBase(newUser);

        }
    }

    private String getRandomTestName() {
        int userNumber = getRandomNumber();
        String name = "test" + Integer.toString(userNumber);

        Log.e(TAG_LOG, "username: " + name);
        return name;
    }


    private int getRandomPoint() {
        int min = 1;
        int max = 25;
        Random random = new Random();
        int points = random.nextInt(max - min + 1) + min; //exclusive of top value
        return points;
    }

    private int getMedalPoint() { //top 10 users
        int min = 26;
        int max = 97;
        Random random = new Random();
        int points = random.nextInt(max - min + 1) + min; //exclusive of top value
        return points;
    }


    private int getRandomNumber() {
        int min = 1;
        int max = 200;
        Random random = new Random();
        int number = random.nextInt(max - min + 1) + min; //exclusive of top value

        Log.e(TAG_LOG, "userNumber: " + number);

        return number;
    }

}
