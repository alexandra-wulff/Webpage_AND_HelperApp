package com.example.autogenerateuser;

public class User {

    private String name;
    //private Long points;
    private int points;


    public User(String name, int points) {
        this.name = name;
        //this.points = points;
        this.points = points;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }
}
