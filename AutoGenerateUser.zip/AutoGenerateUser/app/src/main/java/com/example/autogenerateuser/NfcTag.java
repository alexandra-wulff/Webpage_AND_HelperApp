package com.example.autogenerateuser;

public class NfcTag {

    private int points;

    public NfcTag(int points) {
        this.points = points;
    }

    public int getPoint() {
        return points;
    }

    public void setPoint(int points) {
        this.points = points;
    }
}
